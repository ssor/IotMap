<?php #php-load.php by zhangxinxu 2010-09-06
	echo '<h2 style="width:500px; padding:20px 40px; font-size:30px;"><a href="http://www.meituan.com/shanghai/deal/shhxz.html" style="color:#399; text-decoration:none;">今日团购：</a>仅售58元！原价118元的鲁班路黑匣子鬼屋体验券！美国团队打造，好莱坞级别鬼屋。阴森恐怖吓破胆，够胆你就来！</h2>';
?>